document.getElementById('loadItems').addEventListener('click', function() {
    var items = _.shuffle(['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5']);
    var ul = document.getElementById('items');
    ul.innerHTML = '';
    items.forEach(function(item) {
        var li = document.createElement('li');
        li.textContent = item;
        ul.appendChild(li);
    });
});
